// src/components/LetterGeneratorModal.js
import React, { useMemo, useState, useEffect } from "react";
import PizZip from "pizzip";
import Docxtemplater from "docxtemplater";
import { saveAs } from "file-saver";

/**
 * Template loading strategy:
 * - If templateSource="local": fetch from /templates/... (public folder)
 * - If templateSource="gdrive": fetch from your Apps Script proxy endpoint
 *
 * You will pass `templateConfig` from Dashboard.
 */
export default function LetterGeneratorModal({
  user,
  onClose,
  templateConfig,
}) {
  // ==== UI options (adjust freely) ====
  const jenisSuratOptions = ["Kurikulum Silabus", "Bahan Tayang Standar"];
  const jenisKurikulumOptions = ["KPK", "ECP", "Jasa Perdagangan"];
  const sifatSuratOptions = ["undangan", "hasil"];
  const lampiranOptions = [
    "-",
    "1 (satu)",
    "2 (dua)",
    "3 (tiga)",
    "4 (empat)",
    "5 (lima)",
  ];
  const jumlahFasilitatorOptions = [2, 3];
  const jumlahBtsOptions = [1, 2, 3];

  const monthTranslation = {
    January: "Januari",
    February: "Februari",
    March: "Maret",
    April: "April",
    May: "Mei",
    June: "Juni",
    July: "Juli",
    August: "Agustus",
    September: "September",
    October: "Oktober",
    November: "November",
    December: "Desember",
  };

  const today = new Date();
  const currentDay = today.getDate();
  const currentMonthEnglish = today.toLocaleString("en-US", { month: "long" });
  const currentMonthID =
    monthTranslation[currentMonthEnglish] || currentMonthEnglish;
  const currentYear = today.getFullYear();

  const [form, setForm] = useState({
    collaborationType: "internal", // internal / external
    jenisSurat: "Kurikulum Silabus",
    jenisKurikulum: "KPK",
    sifatSurat: "undangan",
    perihalKpk: "persiapan pelatihan",
    bulanAngka: "",
    bulanHuruf: "",
    lampiran: "-",
    mitraKerjasama: "",
    topikRapat: "",
    tanggal: "",
    waktu: "",
    tahapEcp: "",
    pimpinan: "Kepala",

    jumlahFasilitator: 2,
    fasilitator1: "",
    fasilitator2: "",
    fasilitator3: "",

    jumlahBts: 1,
    btsPelatihan1: "",
    btsPelatihan2: "",
    btsPelatihan3: "",
    btsMateri1: "",
    btsMateri2: "",
    btsMateri3: "",

    instansi: "",
    perusahaan1: "",
    perusahaan2: "",
    perusahaan3: "",
  });

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const placeholders = useMemo(() => {
    const jumlahBts = Number(form.jumlahBts) || 0;

    const pelatihanConjunction =
      jumlahBts === 2
        ? `"${form.btsPelatihan1}" dan "${form.btsPelatihan2}"`
        : `"${form.btsPelatihan1}"`;

    const materiConjunction =
      jumlahBts === 2
        ? `"${form.btsMateri1}" dan "${form.btsMateri2}"`
        : `"${form.btsMateri1}"`;

    const base = {
      "[bulan_angka]": String(form.bulanAngka || ""),
      "[bulan_huruf]": String(form.bulanHuruf || ""),
      "[lampiran]": String(form.lampiran || ""),
      "[fasilitator1]": String(form.fasilitator1 || ""),
      "[fasilitator2]": String(form.fasilitator2 || ""),
      "[fasilitator3]": String(form.fasilitator3 || ""),
      "[instansi]": String(form.instansi || ""),
      "[perusahaan1]": String(form.perusahaan1 || ""),
      "[perusahaan2]": String(form.perusahaan2 || ""),
      "[perusahaan3]": String(form.perusahaan3 || ""),
      "[mitra_kerjasama]": String(form.mitraKerjasama || ""),
      "[topik_rapat]": String(form.topikRapat || ""),
      "[hari_tanggal]": String(form.tanggal || ""),
      "[waktu]": String(form.waktu || ""),
      "[pimpinan]": String(form.pimpinan || ""),
      "[tahap_ECP]": String(form.tahapEcp || ""),
      "[pelatihan1]": String(pelatihanConjunction || ""),
      "[pelatihan2]": String(form.btsPelatihan2 || ""),
      "[pelatihan3]": String(form.btsPelatihan3 || ""),
      "[materi1]": String(materiConjunction || ""),
      "[materi2]": String(form.btsMateri2 || ""),
      "[materi3]": String(form.btsMateri3 || ""),
    };

    if (form.collaborationType === "internal") {
      base["[today]"] = `${currentDay} ${currentMonthID} ${currentYear}`;
    }

    return base;
  }, [form, currentDay, currentMonthID, currentYear]);

  const validate = () => {
    if (!form.jenisSurat) return "Jenis surat wajib diisi";
    if (!form.sifatSurat) return "Sifat surat wajib diisi";
    if (!form.lampiran) return "Lampiran wajib diisi";
    if (!form.topikRapat) return "Topik rapat wajib diisi";
    if (!form.tanggal) return "Hari/Tanggal wajib diisi";
    if (!form.waktu) return "Waktu wajib diisi";
    if (!form.bulanAngka || !form.bulanHuruf)
      return "Bulan angka & huruf wajib diisi";
    return null;
  };

  // --- template resolver (you can customize mapping exactly like ipynb) ---
  const getTemplateKey = () => {
    // Example key pattern:
    // internal_undangan, internal_hasil, external_undangan, external_hasil
    return `${form.collaborationType}_${form.sifatSurat}`;
  };

  const getTemplateUrl = () => {
    const key = getTemplateKey();
    const t = templateConfig?.templates?.[key];

    if (!t) {
      throw new Error(`Template config not found for key: ${key}`);
    }

    // t can be:
    // { source: "local", path: "/templates/xxx.docx" }
    // { source: "gdrive", fileId: "..." }
    if (t.source === "local") return t.path;

    if (t.source === "gdrive") {
      const proxy = templateConfig?.gdriveProxyUrl;
      if (!proxy) throw new Error("Missing gdriveProxyUrl in templateConfig");
      // Use Apps Script proxy: ?fileId=...
      return `${proxy}?fileId=${encodeURIComponent(t.fileId)}`;
    }

    throw new Error(`Unknown template source: ${t.source}`);
  };

  const replacePlaceholdersInDocx = (arrayBuffer) => {
    const zip = new PizZip(arrayBuffer);

    // We edit XML directly for [placeholder] format.
    const xmlPath = "word/document.xml";
    let xml = zip.file(xmlPath).asText();

    Object.entries(placeholders).forEach(([key, val]) => {
      xml = xml.split(key).join(String(val ?? ""));
    });

    zip.file(xmlPath, xml);

    // Optional: ensure docxtemplater doesn't complain (some templates have tags)
    // We still instantiate it to keep docx consistent in some cases.
    try {
      const doc = new Docxtemplater(zip, {
        paragraphLoop: true,
        linebreaks: true,
      });
      doc.render();
    } catch {
      // If your template contains no docxtemplater tags, this is fine to ignore.
    }

    return zip.generate({
      type: "blob",
      mimeType:
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    });
  };

  const handleGenerate = async () => {
    const err = validate();
    if (err) return alert(err);

    try {
      const templateUrl = getTemplateUrl();
      const res = await fetch(templateUrl);

      if (!res.ok) throw new Error(`Failed to load template: ${res.status}`);

      const buf = await res.arrayBuffer();
      const outBlob = replacePlaceholdersInDocx(buf);

      const fileName = `surat_${getTemplateKey()}_${Date.now()}.docx`;
      saveAs(outBlob, fileName);
    } catch (e) {
      console.error(e);
      alert(`Gagal generate surat: ${e.message}`);
    }
  };

  // Quality of life: auto-fill bulan huruf if kosong (optional)
  useEffect(() => {
    if (!form.bulanHuruf && form.bulanAngka) {
      const m = Number(form.bulanAngka);
      const map = [
        "",
        "Januari",
        "Februari",
        "Maret",
        "April",
        "Mei",
        "Juni",
        "Juli",
        "Agustus",
        "September",
        "Oktober",
        "November",
        "Desember",
      ];
      if (m >= 1 && m <= 12) setField("bulanHuruf", map[m]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.bulanAngka]);

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b bg-slate-50">
          <div>
            <div className="font-bold text-slate-900">Generator Surat</div>
            <div className="text-xs text-slate-500">
              Template:{" "}
              {(() => {
                try {
                  return getTemplateKey();
                } catch {
                  return "-";
                }
              })()}
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-red-600 text-xl"
          >
            ✕
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
          {/* LEFT: form */}
          <div className="p-6 border-b lg:border-b-0 lg:border-r">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Tipe Kolaborasi
                </label>
                <select
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.collaborationType}
                  onChange={(e) =>
                    setField("collaborationType", e.target.value)
                  }
                >
                  <option value="internal">internal</option>
                  <option value="external">external</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Sifat Surat
                </label>
                <select
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.sifatSurat}
                  onChange={(e) => setField("sifatSurat", e.target.value)}
                >
                  {sifatSuratOptions.map((x) => (
                    <option key={x} value={x}>
                      {x}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Jenis Surat
                </label>
                <select
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.jenisSurat}
                  onChange={(e) => setField("jenisSurat", e.target.value)}
                >
                  {jenisSuratOptions.map((x) => (
                    <option key={x} value={x}>
                      {x}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Jenis Kurikulum
                </label>
                <select
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.jenisKurikulum}
                  onChange={(e) => setField("jenisKurikulum", e.target.value)}
                >
                  {jenisKurikulumOptions.map((x) => (
                    <option key={x} value={x}>
                      {x}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Bulan Angka
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.bulanAngka}
                  onChange={(e) => setField("bulanAngka", e.target.value)}
                  placeholder="12"
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Bulan Huruf
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.bulanHuruf}
                  onChange={(e) => setField("bulanHuruf", e.target.value)}
                  placeholder="Desember"
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Lampiran
                </label>
                <select
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.lampiran}
                  onChange={(e) => setField("lampiran", e.target.value)}
                >
                  {lampiranOptions.map((x) => (
                    <option key={x} value={x}>
                      {x}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Pimpinan
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.pimpinan}
                  onChange={(e) => setField("pimpinan", e.target.value)}
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-sm font-semibold text-slate-700">
                  Topik Rapat
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.topikRapat}
                  onChange={(e) => setField("topikRapat", e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Hari/Tanggal
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.tanggal}
                  onChange={(e) => setField("tanggal", e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Waktu
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.waktu}
                  onChange={(e) => setField("waktu", e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Jumlah Fasilitator
                </label>
                <select
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.jumlahFasilitator}
                  onChange={(e) =>
                    setField("jumlahFasilitator", Number(e.target.value))
                  }
                >
                  {jumlahFasilitatorOptions.map((x) => (
                    <option key={x} value={x}>
                      {x}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Instansi
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.instansi}
                  onChange={(e) => setField("instansi", e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Fasilitator 1
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.fasilitator1}
                  onChange={(e) => setField("fasilitator1", e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-700">
                  Fasilitator 2
                </label>
                <input
                  className="w-full mt-1 px-3 py-2 border rounded-lg"
                  value={form.fasilitator2}
                  onChange={(e) => setField("fasilitator2", e.target.value)}
                />
              </div>

              {form.jumlahFasilitator === 3 && (
                <div className="sm:col-span-2">
                  <label className="text-sm font-semibold text-slate-700">
                    Fasilitator 3
                  </label>
                  <input
                    className="w-full mt-1 px-3 py-2 border rounded-lg"
                    value={form.fasilitator3}
                    onChange={(e) => setField("fasilitator3", e.target.value)}
                  />
                </div>
              )}

              <div className="sm:col-span-2">
                <button
                  onClick={handleGenerate}
                  className="w-full mt-2 px-4 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                >
                  Generate & Download .docx
                </button>

                <div className="text-xs text-slate-500 mt-2">
                  Sumber template: <b>{templateConfig?.mode || "?"}</b>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: placeholder preview */}
          <div className="p-6 bg-slate-50">
            <div className="bg-white rounded-2xl border p-5">
              <div className="font-bold text-slate-900 mb-2">
                Placeholder yang diisi
              </div>
              <pre className="text-xs whitespace-pre-wrap bg-slate-50 border rounded-xl p-4 overflow-auto max-h-[520px]">
                {JSON.stringify(placeholders, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
